import pandas as pd
import json
from tqdm import tqdm
with open('ditiller_comment_final_0715.json','r',encoding='utf-8') as f:
    #   將所有 userID 取出
    data = json.load(f)
    raw_user_list = []
    for d in data:
        for u in d['comment']:
            user = d['comment'][f'{u}']['user_name']
            raw_user_list.append(user)
    user_list = list(set(raw_user_list))

    '''distiller: 73283個用戶 408394則評論 平均一個用戶對5-6支酒評論'''
    #   抓出相同 userID 在不同酒的評論
    user_data_list = []
    for user in tqdm(user_list):
        user_data = {}
        user_data['user_name'] = user
        comment_list = []
        user_data['comments'] = comment_list
        for d in data:
            tmp = {}
            for u in d['comment']:
                # print('')
                # print(d['comment'][f'{u}']['user_name'])
                if d['comment'][f'{u}']['user_name'] == user:
                    tmp['whiskey_name'] = d['whiskey_name']
                    tmp['score'] = d['comment'][f'{u}']['score']
                    tmp['text'] = d['comment'][f'{u}']['text']
                    comment_list.append(tmp)
        user_data_list.append(user_data)
    with open('ditiller_user_data.json','w',encoding='utf-8') as f1:
        final_data = json.dumps(user_data_list,indent=3)
        print(final_data)
        f1.write(final_data)